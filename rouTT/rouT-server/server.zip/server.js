var express = require('express');
var app = express();
var fs = require("fs");

const pg = require('pg')  
const conString = 'postgres://postgres:postgres@localhost/postgres' // make sure to match your own database's credentials



var config = {
  user: 'postgres', //env var: PGUSER 
  database: 'postgres', //env var: PGDATABASE 
  password: 'postgres', //env var: PGPASSWORD 
  port: 5432, //env var: PGPORT 
  max: 10, // max number of clients in the pool 
  idleTimeoutMillis: 30000, // how long a client is allowed to remain idle before being closed 
};

var pool = new pg.Pool(config);

app.get('/app/user/login', function (req, res) {
      console.log(req.query.username + " - " + req.query.password);
	    
      var httpStatusCode = 200;
      var queryResult;
    	// pg.connect(conString, function (err, client, done) {  
     //  		if (err) {
     //    			return console.error('error fetching client from pool', err);
     //  		}
      	  
     //      client.query('SELECT * FROM public.users WHERE name= $1 AND password= $2', [req.query.username, req.query.password], function (err, result) {
     //    		// done();

     //    		if (err || result.rows[0] == undefined){
     //          httpStatusCode = 403;
     //          console.log(err);
     //        }
     //    		else
     //            httpStatusCode = 200;

     //        res.writeHead(httpStatusCode, {
     //              'Content-Type':'text/plain',
     //              'Access-Control-Allow-Origin':'*',
     //              'Access-Control-Allow-Methods':'GET,PUT,POST,DELETE'
     //            });
     //      res.end();
     //        // client.end(function(err){
     //        //   if(err) throw err;
     //        // });
     //  		});

          

     //      client.end(function(err){

     //      });
    	// });

    pool.connect(function ( err, client, done){
      if(err)
        console.log(err);

      client.query('SELECT * FROM public.users WHERE name= $1 AND password= $2', [req.query.username, req.query.password], function (err, result) {
      // client.query('SELECT * FROM public.users WHERE name= $1 AND password= $2', [req.query.username, req.query.password], function (err, result) {
        done();

        if(err || result.rowCount == 0){
          httpStatusCode=403;
          console.log('err');
        }

        queryResult = result;
        console.log(queryResult);
      });
    });

    pool.on('error', function(err, client){
        console.error('idle client error', err.message, err.stack)
    });

                res.writeHead(httpStatusCode, {
                  'Content-Type':'text/plain',
                  'Access-Control-Allow-Origin':'*',
                  'Access-Control-Allow-Methods':'GET,PUT,POST,DELETE'
                });
          res.end();    
})

app.get('/app/user/register', function ( req, res) {
    pg.connect(conString, function (err, client, done){
      if(err) {
        return console.error();
      }

      client.query('INSERT INTO public.users(name, password) VALUES($1, $2)', [req.query.username, req.query.password], function (err, result) {
        done();

        if(err || result.rowCount == 0){
          res.writeHead(403, {
                'Content-Type':'text/plain',
                'Access-Control-Allow-Origin':'*',
                'Access-Control-Allow-Methods':'GET,PUT,POST,DELETE'
            });
        }

        res.writeHead(200, {
                'Content-Type':'text/plain',
                'Access-Control-Allow-Origin':'*',
                'Access-Control-Allow-Methods':'GET,PUT,POST,DELETE'
            });

        res.end();
      });
    });

    // res.end();
})

app.get('/app/memories/add', function ( req, res) {
    pg.connect(conString, function (err, client, done){
      if(err) {
        return console.error();
      }

      client.query('INSERT INTO public.diary(id,uid,note,date) VALUES(1, $1, $2, NULL)', [req.query.uid, req.query.note], function (err, result) {
        done();

        if(err || result.rowCount == 0){
          res.writeHead(403, {
                'Content-Type':'text/plain',
                'Access-Control-Allow-Origin':'*',
                'Access-Control-Allow-Methods':'GET,PUT,POST,DELETE'
            });
        }

        res.writeHead(200, {
                'Content-Type':'text/plain',
                'Access-Control-Allow-Origin':'*',
                'Access-Control-Allow-Methods':'GET,PUT,POST,DELETE'
            });
        
        res.end();
      });
    });

    // res.end();
})

var server = app.listen(8081, function () {

  var host = server.address().address
  var port = server.address().port

  console.log("Example app listening at http://%s:%s", host, port)

})